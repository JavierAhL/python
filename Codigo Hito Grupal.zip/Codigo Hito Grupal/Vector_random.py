import random
numeros = random.sample(range(1, 11), 10)
print()
#Vector sin ordenar 
print(numeros)

#Vector con el algoritmo de ordenación
numeros.sort()
print(numeros)
