def actividad1():
    producto = input("Introduce el producto (camisa, chaqueta, pantalón) o 9 para salir: ")
while True:
    producto = input("Introduce el producto que desees comprar : ")
    if producto == "9":
        break
    if producto.lower() in ["camisa", "chaqueta", "pantalón"]:
        try:
            unidades = int(input("Cuántas unidades necesitas? "))
            precio = round(unidades * 5.95, 2)
        except ValueError:
            print("Por favor introduce un número válido")
    else:
        print("Producto no válido. Por favor introduce camisa, chaqueta o pantalón.")
    producto = input("Introduce el producto (camisa, chaqueta, pantalón) o 9 para salir: ")
    
    print("Se sale de la app...")
