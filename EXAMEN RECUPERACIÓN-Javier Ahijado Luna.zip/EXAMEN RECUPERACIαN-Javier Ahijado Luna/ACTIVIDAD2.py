# Se crea clase base Director
class Director:
    def __init__(self, nombre, ciudad):
        self.nombre = nombre
        self.ciudad = ciudad

# Se crea clase heredado a Director
class Cliente(Director):
    def __init__(self, nombre, ciudad):
        self.nombre = nombre
        self.ciudad = ciudad

# Se crea clase Proveedor heredado a Director
class Proveedor(Director):
    def __init__(self, nombre, ciudad):
        self.nombre = nombre
        self.ciudad = ciudad

# Se crea clase Empleado heredado a Director
class Empleado(Director):
    def __init__(self, nombre, ciudad):
        self.nombre = nombre
        self.ciudad = ciudad

# Se crea dos clientes y se almacenan en un array
clientes = [Cliente("Javier", "Madrid"), Cliente("Alberto", "Sevilla")]

# Para que se pongan los nombres de los clientes
for cliente in clientes:
    print(cliente.nombre)

# Se crea dos empleados más y se muestra su nombre y la ciudad de donde son.
empleado1 = Empleado("Pablo", "Málaga")
empleado2 = Empleado("Jorge", "Cadiz")
print(empleado1.nombre, empleado1.ciudad)
print(empleado2.nombre, empleado2.ciudad)